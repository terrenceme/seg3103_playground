import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class ExampleTest {
  @Test
  void makingSureJUnitConfigured() {
    assertEquals(1, 1);
  }
}